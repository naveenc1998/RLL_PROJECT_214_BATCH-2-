export class Salary {

    id!: number;
    emp_name!: string;
    basic_pay!: number;
    deductions!: number;
    net_pay!: number;
    month!: string;

}
